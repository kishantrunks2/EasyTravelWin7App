﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;

namespace Travel_Easy
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        

        private void goButton_Click(object sender, RoutedEventArgs e)
        {
            string myPlace = placeTextBox.Text;
            myPlace = myPlace.Replace(" ", "%20");
            var queryData = string.Format("?Text={0}",myPlace);
            NavigationService.Navigate(new Uri("/placePage.xaml" + queryData, UriKind.Relative));

        }

        private void ContentPanel_Loaded(object sender, RoutedEventArgs e)
        {
            placeTextBox.Focus();
        }
    }
}