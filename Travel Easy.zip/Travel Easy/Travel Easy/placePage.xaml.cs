﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.IO;
using System.IO.IsolatedStorage;
using System.ComponentModel;
using Microsoft.Phone.Tasks;
using System.Text;

using System.Windows.Media.Imaging;
namespace Travel_Easy
{
    public partial class placePage : PhoneApplicationPage
    {
        int n = 5;
        int first = 0, second = 0;
        int i = 0;
// string[] events = new string[5];
       // string[] phone = new string[5];
      //  string[] address = new string[5];

        BitmapImage mostlyCloudy = new BitmapImage(new Uri("/aaa.jpg", UriKind.Relative));
        BitmapImage partlyCloudy = new BitmapImage(new Uri("/sunclouds.jpg", UriKind.Relative));
        BitmapImage hot = new BitmapImage(new Uri("/sunny.jpg", UriKind.Relative));
        BitmapImage sunny = new BitmapImage(new Uri("/h.jpg", UriKind.Relative));
        BitmapImage freezingRain = new BitmapImage(new Uri("/images.jpg", UriKind.Relative));
        BitmapImage windy = new BitmapImage(new Uri("/windy.jpg", UriKind.Relative));
        BitmapImage automobilesWall = new BitmapImage(new Uri("/Images/automobilesWall.jpg", UriKind.Relative));
        BitmapImage shoppingWall = new BitmapImage(new Uri("/Images/shoppingWall.jpg", UriKind.Relative));
        
        string woeid;
        string place;
        string appId = "aJEK4ifV34EGSKHX6yBonZZQmWLg78idEb1h3hxfbZjJIo3bQoBK9L4UkKj2TCBqOFWBwRk";

        public placePage()
        {
            InitializeComponent();
           
        }

        public class Const
        {
            public static string TextTag = "Text";

        }

        protected override void OnNavigatedTo(System.Windows.Navigation.NavigationEventArgs e)
        {
            var data = this.NavigationContext.QueryString;

            if (data.ContainsKey(Const.TextTag))
                place = data[Const.TextTag];
            base.OnNavigatedTo(e);

        }




        void Aparna_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            lock (this)
            {
                string s = e.Result;

                int first = s.IndexOf("<woeid>") + "<woeid>".Length;
                int last = s.IndexOf("</woeid>");
                woeid = s.Substring(first, last - first);

                //textBlock1.Text = woeid;
                weather();
            }
        }

        public void weather()
        {
            textBlock1.Text = place;
            WebClient weather = new WebClient();
            weather.AllowReadStreamBuffering = true;
            weather.DownloadStringAsync(new Uri("http://weather.yahooapis.com/forecastrss?w=" + woeid));
            weather.DownloadStringCompleted += new DownloadStringCompletedEventHandler(weather_DownloadStringCompleted);


        }

        void weather_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            lock (this)
            {

                string s = e.Result;

               int first = s.IndexOf("<geo:long>")+"<geo:long>".Length;
                  int   last = s.IndexOf("</geo:long>");
                    string longitude = s.Substring(first, last - first);
                
                         first = s.IndexOf("<geo:lat>")+"<geo:lat>".Length;
                     last = s.IndexOf("</geo:lat>");
                    string lat = s.Substring(first, last - first);

                   first = s.IndexOf("<pubDate>")+"<pubDate>".Length;
                     last = s.IndexOf("</pubDate>");
                    string pubdate = s.Substring(first, last - first);

                  first = s.IndexOf("<yweather:condition") + "<yweather:condition".Length;
                    last = s.IndexOf("/>", first);
                    string conditions = s.Substring(first, last - first); 

                    first = s.IndexOf("<yweather:condition  text=\"") + "<yweather:condition  text=\"".Length;
                    last = s.IndexOf("\"", first);
                    string forecast = s.Substring(first, last - first);

              /*  int third = conditions.IndexOf("text")+"text".Length+2;
                int fourth = conditions.IndexOf("code", third);
                string forecast = conditions.Substring(third, (fourth-3) - third); */

                int third = conditions.IndexOf("temp") + "temp".Length + 2;
                int fourth = conditions.IndexOf("\"", third);
                string temp = conditions.Substring(third, fourth - third);

             /*   first = s.IndexOf("<img src") + "<img src".Length+2;
                last = s.IndexOf("/><br />",first);
                string imgLink = s.Substring(first, (last-1) - first);*/

                tempTextBlock.Text = "Tempearture: "+temp+" F";
                latLongTextBlock.Text = "Geo Co-Ords: " + lat + "  " + longitude;
                dateTextBlock.Text = pubdate;

                forecastTextBlock.Text = "Today's Forecast: "+forecast;


                if (forecast == "Partly Cloudy")
                {
                    image1.Source = partlyCloudy;

                }

                else if (forecast == "Mostly Cloudy")
                {

                    image1.Source = mostlyCloudy;


                }
                else if (forecast == "Hot")
                {
                    image1.Source = sunny;
                }

                else if (forecast == "Sunny")
                {
                    image1.Source = hot;
                }
                else if (forecast == "Freezing Rain")
                {
                    image1.Source = freezingRain;
                }
                else if (forecast == "Windy")
                {
                    image1.Source = windy;
                }
                else if (forecast == "Snow" || forecast == "Heavy Snow")
                {
                    image1.Source = freezingRain;
                }
                else if (forecast == "Fair")
                {
                    image1.Source = partlyCloudy;
                }

             /*   Uri uri = new Uri(imgLink, UriKind.Absolute);
                ImageSource imgSource = new BitmapImage(uri);
                image1.Source = imgSource;

                forecastTextBlock.Text = imgLink;*/
            /*    Uri uri = new Uri(imgLink, UriKind.Absolute);
    image1.Source = new BitmapImage(uri); */



                        }
        }

        private void ContentPanel_Loaded(object sender, RoutedEventArgs e)
        {
            WebClient Aparna = new WebClient();
            Aparna.DownloadStringAsync(new Uri("http://where.yahooapis.com/v1/places.q('" + place + "')?appid=" + appId));
            Aparna.DownloadStringCompleted += new DownloadStringCompletedEventHandler(Aparna_DownloadStringCompleted);
     
        }

        private void p2_Loaded(object sender, RoutedEventArgs e)
        {
            WebClient restaurants = new WebClient();
            restaurants.AllowReadStreamBuffering = true;
            restaurants.DownloadStringAsync(new Uri("https://api.foursquare.com/v2/venues/search?near=%27"+place+"%27&query=%27restaurant%27&oauth_token=2CXGSEQMQGMLEL24R2RDIVAXJGEW1X2NCWHEGQN1ZCAT233K&v=20120812"));
            restaurants.DownloadStringCompleted += new DownloadStringCompletedEventHandler(restaurants_DownloadStringCompleted);

        }

        void restaurants_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            lock (this)
            {
                string s = e.Result;
              //  textBlock2.Text = s;
              
           
                  
                    first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                    second = s.IndexOf("\"",first);
                    string event1 = s.Substring(first, second - first);
                    event1.ToUpper();
                    O1.Text = event1;

                    event1 = "";

                    first = s.IndexOf("formattedPhone\":\"",second) + "formattedPhone\":\"".Length;
                    second = s.IndexOf("\"", first);
                    event1 += s.Substring(first, second - first);
                    event1 += '\n';


                    first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                    second = s.IndexOf("\"", first);
                    event1 += s.Substring(first, second - first);
                                            P1.Text = event1;



                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event2 = s.Substring(first, second - first);
                      event2.ToUpper();
                      O2.Text = event2;

                      event2 = "";

                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event2 += s.Substring(first, second - first);
                      event2 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event2 += s.Substring(first, second - first);
                      P2.Text = event2;




                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event3 = s.Substring(first, second - first);
                      event3.ToUpper();
                      O3.Text = event3;

                      event3 = "";


                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event3 += s.Substring(first, second - first);
                      event3 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event3 += s.Substring(first, second - first);
                      P3.Text = event3;



                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event4 = s.Substring(first, second - first);
                      event4.ToUpper();
                      O4.Text = event4;

                      event4 = "";
                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event4 += s.Substring(first, second - first);
                      event4 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event4 += s.Substring(first, second - first);
                      P4.Text = event4;



                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event5 = s.Substring(first, second - first);
                      event5.ToUpper();
                      O5.Text = event5;

                      event5 = "";

                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event5 += s.Substring(first, second - first);
                      event5 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event5 += s.Substring(first, second - first);
                      P5.Text = event5;




                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event6 = s.Substring(first, second - first);
                      event3.ToUpper();
                      O6.Text = event6;

                      event6 = "";


                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event6 += s.Substring(first, second - first);
                      event6 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event6 += s.Substring(first, second - first);
                      P6.Text = event6;



                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event7 = s.Substring(first, second - first);
                      event7.ToUpper();
                      O7.Text = event7;

                      event7 = "";
                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event7 += s.Substring(first, second - first);
                      event7 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event7 += s.Substring(first, second - first);
                      P7.Text = event7;



                      first = s.IndexOf("name\":\"", second) + "name\":\"".Length;
                      second = s.IndexOf("\"", first);
                      string event8 = s.Substring(first, second - first);
                      event8.ToUpper();
                      O8.Text = event8;

                      event8 = "";

                      first = s.IndexOf("formattedPhone\":\"", second) + "formattedPhone\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event8 += s.Substring(first, second - first);
                      event8 += '\n';

                      first = s.IndexOf("address\":\"", second) + "address\":\"".Length;
                      second = s.IndexOf("\"", first);
                      event8 += s.Substring(first, second - first);
                      P8.Text = event8;
                

                //textBlock2.Text = event1+"\n\n"+event2+"\n\n"+event3+"\n\n"+event4+"\n\n"+event5+"\n\n";
        }
        }

        private void O1_Tap(object sender, GestureEventArgs e)
        {
            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p="+O1.Text.Replace(" ","%20")+"%20"+place, UriKind.Absolute);
            wtb.Show();
        }

        private void O2_Tap(object sender, GestureEventArgs e)
        {
            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O2.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();

        }

        private void O3_Tap(object sender, GestureEventArgs e)
        {
            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O3.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();

        }

        private void O4_Tap(object sender, GestureEventArgs e)
        {

            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O4.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();
        }

        private void O5_Tap(object sender, GestureEventArgs e)
        {

            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O5.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();
        }

        private void O6_Tap(object sender, GestureEventArgs e)
        {
            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O6.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();

        }

        private void O7_Tap(object sender, GestureEventArgs e)
        {

            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O7.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();
        }

        private void O8_Tap(object sender, GestureEventArgs e)
        {
            WebBrowserTask wtb = new WebBrowserTask();
            wtb.Uri = new Uri("http://search.yahoo.com/search?p=" + O8.Text.Replace(" ", "%20") + "%20" + place, UriKind.Absolute);
            wtb.Show();

        }





/*
        private void p3_Loaded(object sender, RoutedEventArgs e)
        {
            WebClient events = new WebClient();
            events.AllowReadStreamBuffering = true;
            events.DownloadStringAsync(new Uri("http://query.yahooapis.com/v1/public/yql?q=select * from upcoming.events where woeid%3D'"+ woeid+"'"));
            events.DownloadStringCompleted += new DownloadStringCompletedEventHandler(events_DownloadStringCompleted);

        }

        void events_DownloadStringCompleted(object sender, DownloadStringCompletedEventArgs e)
        {
            lock (this)
            {
                string s = e.Result;
                textBlock1.Text = s;
            }
        }
    */
    }
        }
    
